# Disease Prediction Flask App (Single File)

A self-contained Flask backend in one file: home page, disease prediction
API, login/register, SQLite database, error handling, and recovery
suggestions.

## Setup

    pip install -r requirements.txt
    python train_model.py     # generates disease_model.pkl + scaler.pkl
    python app.py             # runs on http://127.0.0.1:5000

(disease_model.pkl and scaler.pkl are already included in this zip, so you
can skip the train_model.py step and just run `python app.py` directly.
Re-run train_model.py any time you want to retrain.)

## Try it

    curl -X POST http://127.0.0.1:5000/register -H "Content-Type: application/json" \
      -d '{"username":"bob","email":"bob@example.com","password":"secret123","confirm_password":"secret123"}'

    curl -c cookies.txt -X POST http://127.0.0.1:5000/login -H "Content-Type: application/json" \
      -d '{"username":"bob","password":"secret123"}'

    curl -b cookies.txt -X POST http://127.0.0.1:5000/api/predict -H "Content-Type: application/json" \
      -d '{"age":63,"sex":1,"cp":3,"trestbps":145,"chol":260,"fbs":1,"restecg":0,"thalach":120,"exang":1,"oldpeak":2.5,"slope":0,"ca":2,"thal":2}'

    curl -b cookies.txt http://127.0.0.1:5000/api/predictions
