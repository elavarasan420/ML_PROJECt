"""
ml/train_model.py
------------------
Builds the dataset and trains the Random Forest model consumed by
app/api/routes.py. Run once (or whenever retraining is needed):

    python ml/train_model.py

WHY A GENERATED DATASET?
This environment has no internet access, so the classic UCI Cleveland Heart
Disease CSV can't be downloaded. This script instead generates a synthetic
dataset mirroring the same 13 clinical features, using a clinically
plausible rule (higher age/cholesterol/blood pressure/exercise angina,
lower max heart rate, etc. -> higher risk) plus noise for the target.

To use REAL data: drop a `heart.csv` (Cleveland Heart Disease format, same
column names, target column named `target`) at ml/dataset.csv and set
USE_SYNTHETIC = False below.
"""

import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "dataset.csv")
MODEL_DIR = os.path.join(BASE_DIR, "model")
MODEL_PATH = os.path.join(MODEL_DIR, "disease_model.pkl")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.pkl")

USE_SYNTHETIC = True

FEATURE_NAMES = [
    "age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
    "thalach", "exang", "oldpeak", "slope", "ca", "thal",
]


def generate_synthetic_dataset(n_samples=1200, seed=42):
    rng = np.random.default_rng(seed)

    age = rng.integers(29, 78, n_samples)
    sex = rng.integers(0, 2, n_samples)
    cp = rng.integers(0, 4, n_samples)
    trestbps = rng.integers(90, 200, n_samples)
    chol = rng.integers(120, 420, n_samples)
    fbs = rng.integers(0, 2, n_samples)
    restecg = rng.integers(0, 3, n_samples)
    thalach = rng.integers(70, 202, n_samples)
    exang = rng.integers(0, 2, n_samples)
    oldpeak = np.round(rng.uniform(0, 6.2, n_samples), 1)
    slope = rng.integers(0, 3, n_samples)
    ca = rng.integers(0, 4, n_samples)
    thal = rng.integers(0, 3, n_samples)

    risk = (
        0.035 * (age - 50)
        + 0.9 * sex
        + 0.6 * (cp >= 2).astype(int)
        + 0.02 * (trestbps - 130)
        + 0.01 * (chol - 200)
        + 0.4 * fbs
        + 0.3 * (restecg > 0).astype(int)
        - 0.02 * (thalach - 150)
        + 0.9 * exang
        + 0.45 * oldpeak
        + 0.5 * (slope == 0).astype(int)
        + 0.6 * ca
        + 0.5 * (thal == 2).astype(int)
        + rng.normal(0, 1.4, n_samples)
    )
    target = (risk > np.median(risk)).astype(int)

    return pd.DataFrame({
        "age": age, "sex": sex, "cp": cp, "trestbps": trestbps, "chol": chol,
        "fbs": fbs, "restecg": restecg, "thalach": thalach, "exang": exang,
        "oldpeak": oldpeak, "slope": slope, "ca": ca, "thal": thal, "target": target,
    })


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)

    if USE_SYNTHETIC or not os.path.exists(DATASET_PATH):
        df = generate_synthetic_dataset()
        df.to_csv(DATASET_PATH, index=False)
        print(f"Synthetic dataset written to {DATASET_PATH} ({len(df)} rows)")
    else:
        df = pd.read_csv(DATASET_PATH)
        print(f"Loaded dataset from {DATASET_PATH} ({len(df)} rows)")

    X = df[FEATURE_NAMES]
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = RandomForestClassifier(
        n_estimators=300, max_depth=8, min_samples_leaf=3,
        random_state=42, n_jobs=-1,
    )
    model.fit(X_train_scaled, y_train)

    preds = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, preds)
    print(f"\nTest accuracy: {acc:.3f}\n")
    print(classification_report(y_test, preds, target_names=["Low Risk", "High Risk"]))

    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    print(f"\nModel saved to {MODEL_PATH}")
    print(f"Scaler saved to {SCALER_PATH}")


if __name__ == "__main__":
    main()
