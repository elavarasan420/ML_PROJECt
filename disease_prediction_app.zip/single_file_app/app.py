"""
app.py
------
Single-file Disease Prediction Flask backend.

Features: home page, disease prediction API, login/register, SQLite
database, error handling, recovery suggestions.

Setup:
    pip install flask scikit-learn pandas numpy joblib
    python train_model.py          # produces disease_model.pkl + scaler.pkl
    python app.py                  # runs on http://127.0.0.1:5000
"""

import functools
import json
import logging
import os
import sqlite3

import joblib
import pandas as pd
from flask import Flask, g, jsonify, redirect, render_template_string, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

# --------------------------------------------------------------------------
# CONFIG
# --------------------------------------------------------------------------

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, "app.db")
MODEL_PATH = os.path.join(BASE_DIR, "disease_model.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pkl")

FEATURE_SPECS = {
    "age": (1, 120), "sex": (0, 1), "cp": (0, 3), "trestbps": (60, 250),
    "chol": (80, 700), "fbs": (0, 1), "restecg": (0, 2), "thalach": (50, 250),
    "exang": (0, 1), "oldpeak": (0, 10), "slope": (0, 2), "ca": (0, 4), "thal": (0, 3),
}
FEATURE_ORDER = list(FEATURE_SPECS.keys())

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("disease_app")

_model = None
_scaler = None


def load_model():
    """Lazily load the trained model + scaler once per process."""
    global _model, _scaler
    if _model is None or _scaler is None:
        _model = joblib.load(MODEL_PATH)
        _scaler = joblib.load(SCALER_PATH)
        logger.info("Model and scaler loaded.")
    return _model, _scaler


# --------------------------------------------------------------------------
# DATABASE (SQLite)
# --------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                input_data TEXT NOT NULL,
                risk_label TEXT NOT NULL,
                risk_probability REAL NOT NULL,
                recovery_suggestions TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)
        db.commit()


# --------------------------------------------------------------------------
# ERROR HANDLING
# --------------------------------------------------------------------------

class APIError(Exception):
    """Raised for expected failures (bad input, auth, not found)."""
    def __init__(self, message, status_code=400, payload=None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.payload = payload or {}

    def to_dict(self):
        body = dict(self.payload)
        body["error"] = self.message
        return body


@app.errorhandler(APIError)
def handle_api_error(err):
    logger.warning("APIError: %s (%s)", err.message, err.status_code)
    return jsonify(err.to_dict()), err.status_code


@app.errorhandler(404)
def handle_404(err):
    return jsonify(error="Resource not found."), 404


@app.errorhandler(405)
def handle_405(err):
    return jsonify(error="Method not allowed."), 405


@app.errorhandler(500)
def handle_500(err):
    # Any unexpected exception lands here. It's already logged by Flask;
    # we log again with a stack trace and return a SAFE, generic message
    # instead of leaking internal details to the client.
    logger.critical("Unhandled exception", exc_info=err)
    return jsonify(error="Internal server error. Please try again later."), 500


# --------------------------------------------------------------------------
# AUTH HELPERS
# --------------------------------------------------------------------------

@app.before_request
def load_logged_in_user():
    user_id = session.get("user_id")
    g.user = None
    if user_id is not None:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def login_required(view):
    @functools.wraps(view)
    def wrapped(**kwargs):
        if g.user is None:
            raise APIError("Authentication required. Please log in first.", status_code=401)
        return view(**kwargs)
    return wrapped


# --------------------------------------------------------------------------
# RECOVERY SUGGESTIONS (rule-based, transparent by design)
# --------------------------------------------------------------------------

GENERAL_LOW_RISK = [
    "Maintain your current healthy habits with regular physical activity (150 min/week).",
    "Continue routine annual check-ups to catch any changes early.",
    "Keep a balanced diet rich in vegetables, fruits, and whole grains.",
]
GENERAL_HIGH_RISK = [
    "Schedule a consultation with a cardiologist for a thorough clinical evaluation.",
    "Begin monitoring blood pressure and cholesterol levels regularly.",
    "Adopt a heart-healthy diet: reduce saturated fat, sodium, and added sugar.",
    "Incorporate light-to-moderate exercise as approved by your doctor.",
    "Avoid smoking and limit alcohol consumption.",
]


def get_recovery_suggestions(features, risk_label):
    suggestions = list(GENERAL_HIGH_RISK if risk_label == "High Risk" else GENERAL_LOW_RISK)

    if features.get("chol", 0) >= 240:
        suggestions.append("Cholesterol is elevated (>=240 mg/dl) — consider a lipid panel review.")
    if features.get("trestbps", 0) >= 140:
        suggestions.append("Resting blood pressure is high (>=140 mmHg) — reduce sodium intake.")
    if features.get("fbs", 0) == 1:
        suggestions.append("Elevated fasting blood sugar — screening for diabetes is recommended.")
    if features.get("exang", 0) == 1:
        suggestions.append("Exercise-induced angina reported — avoid strenuous activity until cleared.")
    if features.get("age", 0) >= 55:
        suggestions.append("Age is a non-modifiable risk factor — prioritize preventive screening.")

    suggestions.append(
        "Disclaimer: generated by a machine learning demo model, NOT a medical diagnosis. "
        "Always consult a licensed healthcare professional."
    )
    return suggestions


# --------------------------------------------------------------------------
# INPUT VALIDATION
# --------------------------------------------------------------------------

def validate_prediction_input(data):
    if not isinstance(data, dict):
        return None, ["Request body must be a JSON object."]

    errors, features = [], {}
    for name, (lo, hi) in FEATURE_SPECS.items():
        if name not in data or data[name] in (None, ""):
            errors.append(f"Missing required field: '{name}'.")
            continue
        try:
            value = float(data[name])
        except (TypeError, ValueError):
            errors.append(f"Field '{name}' must be a number.")
            continue
        if not (lo <= value <= hi):
            errors.append(f"Field '{name}' must be between {lo} and {hi} (got {value}).")
            continue
        features[name] = value

    unexpected = set(data.keys()) - set(FEATURE_SPECS.keys())
    if unexpected:
        errors.append(f"Unexpected field(s): {', '.join(sorted(unexpected))}.")

    return (None, errors) if errors else (features, [])


# --------------------------------------------------------------------------
# ROUTES: HOME PAGE
# --------------------------------------------------------------------------

HOME_TEMPLATE = """
<!doctype html><html><head><title>Disease Prediction API</title></head>
<body style="font-family: sans-serif; max-width: 700px; margin: 40px auto;">
  <h1>🩺 Disease Prediction API</h1>
  <p>{{ "Logged in as " + user if user else "Not logged in." }}</p>
  <h3>Endpoints</h3>
  <ul>
    <li>POST /register — {username, email, password, confirm_password}</li>
    <li>POST /login — {username, password}</li>
    <li>POST /logout</li>
    <li>POST /api/predict — 13 clinical features (auth required)</li>
    <li>GET /api/predictions — your prediction history (auth required)</li>
    <li>GET /health — liveness check</li>
  </ul>
</body></html>
"""


@app.route("/")
def home():
    return render_template_string(HOME_TEMPLATE, user=g.user["username"] if g.user else None)


@app.route("/health")
def health():
    return jsonify(status="ok")


# --------------------------------------------------------------------------
# ROUTES: LOGIN / REGISTER
# --------------------------------------------------------------------------

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or request.form
    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    confirm = data.get("confirm_password", password)

    errors = []
    if len(username) < 3:
        errors.append("Username must be at least 3 characters.")
    if "@" not in email or "." not in email:
        errors.append("A valid email address is required.")
    if len(password) < 6:
        errors.append("Password must be at least 6 characters.")
    if password != confirm:
        errors.append("Passwords do not match.")
    if errors:
        raise APIError("Registration failed.", payload={"details": errors})

    db = get_db()
    try:
        db.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
            (username, email, generate_password_hash(password)),
        )
        db.commit()
    except sqlite3.IntegrityError:
        raise APIError(f"Username '{username}' or email is already registered.")

    logger.info("New user registered: %s", username)
    return jsonify(message="Registration successful. Please log in."), 201


@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or request.form
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

    if user is None or not check_password_hash(user["password_hash"], password):
        raise APIError("Incorrect username or password.", status_code=401)

    session.clear()
    session["user_id"] = user["id"]
    logger.info("User logged in: %s", username)
    return jsonify(message=f"Welcome back, {username}!", user_id=user["id"])


@app.route("/logout", methods=["POST"])
def logout():
    username = g.user["username"] if g.user else None
    session.clear()
    logger.info("User logged out: %s", username)
    return jsonify(message="Logged out.")


# --------------------------------------------------------------------------
# ROUTES: DISEASE PREDICTION API
# --------------------------------------------------------------------------

@app.route("/api/predict", methods=["POST"])
@login_required
def predict():
    body = request.get_json(silent=True)
    if body is None:
        raise APIError("Request must have Content-Type: application/json and a JSON body.")

    features, errors = validate_prediction_input(body)
    if errors:
        raise APIError("Invalid input.", payload={"details": errors})

    model, scaler = load_model()
    X = pd.DataFrame([[features[n] for n in FEATURE_ORDER]], columns=FEATURE_ORDER)
    X_scaled = scaler.transform(X)

    pred = int(model.predict(X_scaled)[0])
    proba = float(model.predict_proba(X_scaled)[0][pred])
    risk_label = "High Risk" if pred == 1 else "Low Risk"
    suggestions = get_recovery_suggestions(features, risk_label)

    db = get_db()
    cursor = db.execute(
        """INSERT INTO predictions
           (user_id, input_data, risk_label, risk_probability, recovery_suggestions)
           VALUES (?, ?, ?, ?, ?)""",
        (g.user["id"], json.dumps(features), risk_label, proba, json.dumps(suggestions)),
    )
    db.commit()
    logger.info("Prediction #%s -> %s (%.1f%%)", cursor.lastrowid, risk_label, proba * 100)

    return jsonify(
        id=cursor.lastrowid,
        risk_label=risk_label,
        risk_probability=round(proba, 4),
        recovery_suggestions=suggestions,
    ), 201


@app.route("/api/predictions", methods=["GET"])
@login_required
def list_predictions():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC", (g.user["id"],)
    ).fetchall()
    results = [
        {
            "id": r["id"], "risk_label": r["risk_label"],
            "risk_probability": r["risk_probability"],
            "input_data": json.loads(r["input_data"]),
            "recovery_suggestions": json.loads(r["recovery_suggestions"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]
    return jsonify(predictions=results, count=len(results))


@app.route("/api/predictions/<int:prediction_id>", methods=["GET"])
@login_required
def get_prediction(prediction_id):
    db = get_db()
    row = db.execute(
        "SELECT * FROM predictions WHERE id = ? AND user_id = ?",
        (prediction_id, g.user["id"]),
    ).fetchone()
    if row is None:
        raise APIError("Prediction not found.", status_code=404)
    return jsonify(
        id=row["id"], risk_label=row["risk_label"], risk_probability=row["risk_probability"],
        input_data=json.loads(row["input_data"]),
        recovery_suggestions=json.loads(row["recovery_suggestions"]),
        created_at=row["created_at"],
    )


# --------------------------------------------------------------------------
# ENTRY POINT
# --------------------------------------------------------------------------

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
